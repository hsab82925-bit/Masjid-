مسجد حاضری رجسٹر — Android APK سورس پیکج

اہم:
- یہ Android Studio/Gradle پروجیکٹ ہے؛ APK اس ZIP کے اندر پہلے سے کمپائل نہیں ہے۔
- APK بنانے کے لیے GitHub Actions workflow شامل ہے: .github/workflows/build-apk.yml
- GitHub پر نیا repository بنائیں، اس ZIP کو extract کرکے تمام فائلیں repository میں upload کریں۔
- Actions ٹیب کھولیں، "Build Android APK" workflow منتخب کریں، Run workflow دبائیں۔
- کامیاب build کے بعد workflow run کے نیچے Artifacts میں Masjid-Hazri-APK ڈاؤن لوڈ کریں۔
- APK کو فون میں کھول کر install کریں؛ اگر Android اجازت مانگے تو اسی فائل/براؤزر کے لیے Install unknown apps اجازت دیں۔
- ایپ کا ڈیٹا فون کے اندر WebView local storage میں رہتا ہے۔ فون کا ڈیٹا صاف یا ایپ uninstall کرنے سے پہلے بیک اپ JSON ضرور بنائیں۔
- PIN اس سادہ ورژن میں مقامی PIN ہے، مضبوط encryption یا اکاؤنٹ سکیورٹی نہیں۔
- ایپ میں بچوں اور حاضری کی معلومات حساس ہو سکتی ہیں؛ فون کا اپنا screen lock فعال رکھیں اور بیک اپ محفوظ رکھیں۔
